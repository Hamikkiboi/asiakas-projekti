'use strict';

const {
    haeKaikkiHenkilot,
    haeYksiHenkilo,
    lisaaHenkilo,
    poistaHenkilo,
    paivitaHenkilo,
    lueValinta,
    tulostaVirhe,
    tulostaLopputeksti
} = require('./apufunktiot');

valikko();

async function valikko() {
    let onLoppu=false;
    do {
        const valinta = await lueValinta();
        switch (valinta){
            case '1': 
                await haeKaikkiHenkilot(); 
                break;
            case '2':
                await haeYksiHenkilo();
                break;
            case '3':
                await lisaaHenkilo();
                break;
            case '4':
                await poistaHenkilo();
                break;
            case '5':
                await paivitaHenkilo();
                break;
            case '6':
                tulostaLopputeksti();
                onLoppu=true;
                break;
            default:
                tulostaVirhe();
        }
    }while(!onLoppu);
} 
