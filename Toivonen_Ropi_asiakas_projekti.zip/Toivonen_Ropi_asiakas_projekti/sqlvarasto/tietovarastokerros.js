'use strict';

const {STATUSKOODIT, STATUSVIESTIT} = require('./statuskoodit');

const Tietokanta = require('./tietokanta');

const optiot =require('./yhteysoptiot.json');

const sql=require('./sqllauseet.json');
const haeKaikkiSql = sql.haeKaikki.join(' ');
const haeSql = sql.hae.join(' ');
const lisaaSql = sql.lisaa.join(' ');
const paivitaSql = sql.paivita.join(' ');
const poistaSql = sql.poista.join(' ');

const { insertParametrit, updateParametrit }=require('./parametrifunktiot');

const PERUSAVAIN=sql.perusavain;

//Tietovarastoluokka

module.exports = class Tietovarasto{
    constructor(){
        this.db = new Tietokanta(optiot);
    }

    get STATUSKOODIT(){
        return STATUSKOODIT;
    };

    haeKaikki(){
        return new Promise( async (resolve,reject)=>{
            try{
                const tulos = await this.db.suoritaKysely(haeKaikkiSql);
                resolve(tulos.kyselynTulos);
            }
            catch(virhe){
                // console.log(virhe);
                reject(STATUSVIESTIT.OHJELMAVIRHE());
            }
        })
    } //haeKaikki loppu

    hae(asiakasnumero){
        return new Promise(async (resolve,reject)=>{
            if(!asiakasnumero){
                reject(STATUSVIESTIT.EI_LOYTYNYT('-- tyhjä --'));
            }
            else{
                try{
                    const tulos = await this.db.suoritaKysely(haeSql,[asiakasnumero]);
                    if(tulos.kyselynTulos.length>0){
                        resolve(tulos.kyselynTulos[0]);
                    }
                    else {
                        reject(STATUSVIESTIT.EI_LOYTYNYT(asiakasnumero))
                    }
                }
                catch(virhe){
                    reject(STATUSVIESTIT.OHJELMAVIRHE());
                }
            }
        });
    } //hae loppu

    lisaa(uusi){
        return new Promise(async (resolve, reject)=>{
            try{
                if (uusi) {
                    if (!uusi[PERUSAVAIN]) {
                        reject(STATUSVIESTIT.EI_LISATTY());
                    }
                    else {
                        const hakutulos = 
                            await this.db.suoritaKysely(haeSql,[uusi[PERUSAVAIN]]);
                        if(hakutulos.kyselynTulos.length>0){
                            reject(STATUSVIESTIT.JO_KAYTOSSA(uusi[PERUSAVAIN]));
                        }
                        else{
                            const status=
                                await this.db.suoritaKysely(lisaaSql,insertParametrit(uusi));
                            resolve(STATUSVIESTIT.LISAYS_OK(uusi[PERUSAVAIN]));
                        }
                    }
                }
                else {
                    reject(STATUSVIESTIT.EI_LISATTY());
                }
            }
            catch(virhe){
                // console.log(virhe);
                reject(STATUSVIESTIT.EI_LISATTY());
            }
        });
    }//lisaa loppu

    poista(asiakasnumero){
        return new Promise(async (resolve,reject)=>{
            if (!asiakasnumero) {  //id nolla menee myös tänne
                reject(STATUSVIESTIT.EI_LOYTYNYT('-- tyhjä --'));
            }
            else {
                try{
                    const status = await this.db.suoritaKysely(poistaSql,[asiakasnumero]);
                    if (status.kyselynTulos.muutetutRivitLkm===0){
                        resolve(STATUSVIESTIT.EI_POISTETTU());
                    }
                    else {
                        resolve(STATUSVIESTIT.POISTO_OK(asiakasnumero));
                    }
                }
                catch(virhe){
                    reject(STATUSVIESTIT.OHJELMAVIRHE());
                }
            }
        });
    }// poista loppu

    paivita(avain, muutettuOlio) {
        return new Promise(async (resolve,reject)=>{
            try {
                if(avain && muutettuOlio){
                    if(muutettuOlio[PERUSAVAIN] != avain){
                        reject(STATUSVIESTIT.AVAIMET_EI_SAMAT(avain,muutettuOlio[PERUSAVAIN]));
                    }
                    else{
                        const tulosGet = await this.db.suoritaKysely(haeSql, [avain]);
                        if(tulosGet.kyselynTulos.length>0){
                            const status = await this.db.suoritaKysely(paivitaSql, updateParametrit(muutettuOlio));
                            if (status.kyselynTulos.muutetutRivitLkm === 0) {
                                resolve(STATUSVIESTIT.EI_PAIVITETTY());
                            }
                            else {
                                resolve(STATUSVIESTIT.PAIVITYS_OK(muutettuOlio[PERUSAVAIN]));
                            }
                        }
                        else {
                            this.lisaa(muutettuOlio)
                                .then(status=>resolve(status))
                                .catch(virhe=>reject(virhe));
                        }  
                    }
                }
                else {
                    reject(STATUSVIESTIT.EI_PAIVITETTY());
                }
            }
            catch(virhe){
                reject(STATUSVIESTIT.EI_PAIVITETTY());
            }  
        });
    } //paivitys loppu

} //luokan loppu