drop database if exists  asiakastietokanta;

create database  asiakastietokanta;

use asiakastietokanta;

create  table asiakas (

    
    asiakasnumero integer not null primary key,
    etunimi varchar(6) not null,
    sukunimi varchar(15) not null,
    lempikarkki varchar(20) not null,
    osoite varchar(24) not null
);

drop user if exists 'jonna'@'localhost';
create user 'jonna'@'localhost' identified by '8LyRYbac';

grant all privileges on asiakastietokanta.* to 'jonna'@'localhost';


insert into asiakas values(1,'Aapeli','Hökki','hedelmäkarkki','Maantie 1234');
insert into asiakas values(2,'Matti','virtanen','salmiakki','Datatie 56');