# REST

# resurssi

localhost:4000/api/asiakas

### palauttaa kaikki asiakkaat json taulukkona
GET /api/asiakkaat

### palauttaa asiakaan numerolla 1
GET  /api/asiakkaat/1

palauttaa
```json
{
    "asiakasnumero": 1,
    "etunimi": "Aapeli",
    "sukunimi": "Hökki",
    "lempikarkki": "hedelmäkarkki",
    "osoite": 4000
}
```
lisaa uusi
POST /api/asiakkaat

paivita
PUT /api/asiakkaat/asiakasnumero

jos asiakasta ei ole, niin lisätään

poistaa
DELETE /api/asiakkaat/1


Metodit:
GET
POST
PUT
DELETE
OPTIONS
HEAD