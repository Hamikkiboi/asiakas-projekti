'use strict';
//(id,etunimi,sukunimi,osasto,palkka)
const insertParametrit = asiakas => [
    +asiakas.asiakasnumero, asiakas.etunimi, asiakas.sukunimi, asiakas.lempikarkki, asiakas.osoite
];

//update henkilo set etunimi=?,sukunimi=?, osasto=?, palkka=? where id=?
const updateParametrit = asiakas => [
    asiakas.etunimi, asiakas.sukunimi, asiakas.lempikarkki, asiakas.osoite, +asiakas.asiakasnumero
]

module.exports={insertParametrit, updateParametrit}