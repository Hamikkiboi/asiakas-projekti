'use strict';

const path=require('path');

const {lue,tulosta} = require('./kirjasto/syotekirjasto');
const {aktiivinenvarasto} = require('./config.json');

const Tietovarasto = 
    require(path.join(__dirname, aktiivinenvarasto,'tietovarastokerros'));

const valikkoTeksti = `
Valitse:

1: hae kaikki henkilöt
2: hae henkilö
3: lisää henkilö
4: poista henkilö
5: muuta henkilön tietoja
6: lopeta

Anna valintasi (1, 2, 3, 4, 5 tai 6): `;

const virheilmoitus = `
###############################
Anna numero 1, 2, 3, 4, 5 tai 6
###############################`;

const lopputeksti = `
##############################################
Kiitos, että käytit huippuhienoa sovellustamme
##############################################
`;

const varasto = new Tietovarasto();

async function lueValinta(){
    return await lue(valikkoTeksti);
}

function tulostaVirhe(){
    tulosta(virheilmoitus);
}

function tulostaLopputeksti(){
    tulosta(lopputeksti);
}

function muodostaStatusviesti(viesti) {
    return `\n########### Status ##########\n${viesti}`;
}

async function haeKaikkiHenkilot() {
    tulosta('\n####### kaikki henkilöt ########');
    for (const henkilo of await varasto.haeKaikki()) {
        tulosta(henkiloRivi(henkilo));
    }
}

function henkiloRivi(henkilo) {
    return `${henkilo.asiakasnumero}: ${henkilo.etunimi} ${henkilo.sukunimi}, ` +
        `${henkilo.tyyppi} (lempikarkki: ${henkilo.lempikarkki} )`
}

async function haeYksiHenkilo() {
    try {
        const id = +await lue('Anna asiakasnumero: ');
        const tulos = await varasto.hae(id);
        tulosta('\n######## hae henkilö ########')
        tulosta(henkiloRivi(tulos));
    }
    catch (virhe) {
        tulosta(muodostaStatusviesti(virhe.viesti));
    }
}

async function lueHenkilonTiedot() {
    const asiakasnumero = +await lue('Anna asiakasnumero: ');
    const etunimi = await lue('Etunimi: ')
    const sukunimi = await lue('Sukunimi:');
    const tyyppi = await lue('tyyppi: ');
    const lempikarkki = await lue('lempikarkki: ');

    return {
        asiakasnumero,
        etunimi,
        sukunimi,
        tyyppi,
        lempikarkki
    };
}

async function lisaaHenkilo() {
    try {
        const uusi = await lueHenkilonTiedot();
        const tulos = await varasto.lisaa(uusi);
        tulosta(muodostaStatusviesti(tulos.viesti));
    }
    catch (virhe) {
        tulosta(muodostaStatusviesti(virhe.viesti));
    }
}

async function paivitaHenkilo() {
    try {
        const muutettu = await lueHenkilonTiedot();
        const tulos = await varasto.paivita(muutettu);
        tulosta(muodostaStatusviesti(tulos.viesti));
    }
    catch (virhe) {
        tulosta(muodostaStatusviesti(virhe.viesti));
    }
}

async function poistaHenkilo() {
    try {
        const id = await lue('Anna asiakasnumero: ');
        const status = await varasto.poista(id);
        tulosta(muodostaStatusviesti(status.viesti));
    }
    catch (virhe) {
        tulosta(muodostaStatusviesti(virhe.viesti));
    }
}

module.exports={
    haeKaikkiHenkilot,
    haeYksiHenkilo,
    lisaaHenkilo,
    poistaHenkilo,
    paivitaHenkilo,
    lueValinta,
    tulostaVirhe,
    tulostaLopputeksti
}